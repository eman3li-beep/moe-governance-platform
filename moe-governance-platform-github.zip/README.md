# منصة حوكمة المجالس واللجان التنسيقية الدولية

نموذج واجهة إلكترونية تفاعلية لعرض تصور منصة حوكمة المجالس واللجان التنسيقية الدولية.

## طريقة النشر على GitHub Pages

1. افتحي GitHub.
2. أنشئي Repository جديد باسم:
   `moe-governance-platform`
3. ارفعي ملف `index.html` داخل المستودع.
4. ادخلي على:
   Settings > Pages
5. عند Source اختاري:
   Deploy from a branch
6. عند Branch اختاري:
   main / root
7. اضغطي Save.
8. بعد دقيقة سيظهر الرابط العام.

سيكون الرابط غالبًا بالشكل:
`https://USERNAME.github.io/moe-governance-platform/`

## الملفات

- `index.html`: ملف المنصة الرئيسي.
